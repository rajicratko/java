/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentxml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

/**
 *
 * @author rajic
 */
public class AssignmentXml {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws JAXBException, FileNotFoundException, ParseException, DatatypeConfigurationException {
      ObjectFactory obj=new ObjectFactory();
      Book knjiga=obj.createBook();
      JAXBContext ctx = JAXBContext.newInstance("assignmentxml");
      Unmarshaller un=ctx.createUnmarshaller();
      Catalog catalog = (Catalog)un.unmarshal(new FileInputStream("Biblioteka.xml"));
      catalog.getBook();
       
      for (Book book:catalog.getBook()){
          String datum1=book.getPublishDate().toXMLFormat();
          SimpleDateFormat smp=new SimpleDateFormat("yyyy-MM-dd");
          Date datum=smp.parse(datum1);
          SimpleDateFormat noviFormat=new SimpleDateFormat("yyyy");
           int formatiranDatum=Integer.parseInt(noviFormat.format(datum));
                if(book.getPrice()>10&&formatiranDatum>2005){
                    System.out.println("AUTOR: "+book.getAuthor()+"\r\n"+"OPIS KNJIGE: "+book.getDescription()+"\r\n"+"CENA KNJIGE: "+book.getPrice()+"\r\n"+"DATUM IZDAVANJA: "+book.getPublishDate()+"\r\n");
                }
        }
    }
}
